-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 24, 2017 at 01:16 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `contact`
--
CREATE DATABASE `contact` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `contact`;

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `add` varchar(90) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`name`, `email`, `add`) VALUES
('pradeep', 'pk@.com', 'ksmdlsmd'),
('eru', 'ryft@.com', 'ertyuidfghjk'),
('arc', '@.com', 'kfdnks'),
('pj', '@.com', 'djsgjsa');
--
-- Database: `kunal`
--
CREATE DATABASE `kunal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kunal`;

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `add` varchar(90) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `add`) VALUES
('asdd', '', ''),
('gsjak', '', ''),
('raj', '', ''),
('raj', 'aksjkja', 'ok'),
('kkg', '@.com', 'jkvldlvfd');

-- --------------------------------------------------------

--
-- Table structure for table `p_info`
--

CREATE TABLE IF NOT EXISTS `p_info` (
  `city` varchar(10) NOT NULL,
  `area` varchar(20) NOT NULL,
  `l_price` int(11) NOT NULL,
  `u_price` int(11) NOT NULL,
  `no_of_bedroom` int(11) NOT NULL,
  `no_of_bathroom` int(11) NOT NULL,
  `radius` int(11) NOT NULL,
  `img` varchar(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `p_info`
--

INSERT INTO `p_info` (`city`, `area`, `l_price`, `u_price`, `no_of_bedroom`, `no_of_bathroom`, `radius`, `img`) VALUES
('Ranchi', 'lalpur', 200000, 700000, 4, 2, 3000, 'page1_img4.jpg'),
('Ranchi', 'Circular road', 200000, 700000, 4, 3, 3000, 'img5.jpg'),
('', '', 0, 0, 0, 0, 0, ''),
('', '', 0, 0, 0, 0, 0, ''),
('Delhi', 'Karol Bagh', 300000, 700000, 6, 4, 4000, '2.jpg'),
('Delhi', 'Jawaharnagar', 450000, 800000, 6, 3, 4500, '3.jpg'),
('Delhi', 'New Delhi', 550000, 750000, 7, 4, 5000, '4.jpg'),
('Delhi', 'New Delhi', 550000, 750000, 7, 4, 5000, '4.jpg'),
('Delhi', 'Nangoli', 200000, 700000, 3, 1, 2000, '5.jpg'),
('Delhi', 'Daria Ganj', 600000, 700000, 9, 4, 5500, '6.jpg'),
('Kolkata', 'Durga Nagar', 550000, 750000, 4, 2, 4000, '8.jpg'),
('', '', 650000, 750000, 6, 3, 5000, '9.jpg'),
('Kolkata', 'Kashipur', 650000, 750000, 6, 3, 5000, '9.jpg'),
('Ranchi', 'lalpur', 200000, 750000, 3, 2, 2000, '49.jpg'),
('', '', 0, 0, 0, 0, 0, ''),
('patna', 'gaya', 300000, 750000, 4, 2, 3000, '17457715_291755931244623_751002113526449'),
('', '', 0, 0, 0, 0, 0, ''),
('ranchi', 'kadru', 0, 0, 0, 0, 0, ''),
('yrhreuwi', 'kjfsdka', 0, 0, 0, 0, 0, ''),
('yrhreuwi', 'kjfsdka', 0, 0, 0, 0, 0, ''),
('dkfjfdk', 'djvkfdj', 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user1`
--

CREATE TABLE IF NOT EXISTS `user1` (
  `name` varchar(10) DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user1`
--

INSERT INTO `user1` (`name`, `mobile`, `email`, `address`) VALUES
('kunal', 9534149880, 'kunal.g15@gmail.com', 'lalpur'),
('kunal', 0, '', ''),
('kunal', 0, '', ''),
('kunal', 0, '', ''),
('', 0, '', ''),
('kunal', 0, '', ''),
('kunal', 0, '', ''),
('kunal', 0, '', ''),
('', 0, '', ''),
('', 0, '', ''),
('hhghg', 9534149880, '', ''),
('pradeep ku', 8409174710, 'pradeepkumar20495@gmail.com', 'kadru anand vihar '),
('fdsf', 0, '', ''),
('fdsf', 9876543210, 'fds', 'fd'),
('gfsdhgfd', 9876543210, 'vfdgdf', ''),
('Ravi', 767678676, 'moneyrrfs', 'fsdfsd'),
('fsdf', 78687, 'fdsf', ''),
('', 0, '', ''),
('fsaf', 8668, 'sdffds', ''),
('fsaf', 8668, 'sdffds', ''),
('fdsf', 788, '', ''),
('sdg', 8975642563, 'fdsfsd@fds.com', ''),
('dsds', 1234567891, 'jfj@.com', ''),
('raj', 8804932321, 'rajkumarstevdevid@gmail.com', 'anand vihar kadru'),
('pradsdds', 1234567890, 'pradeepkumar20495@gmail.com', 'ksdfm'),
('pk', 1234567890, '@.com', 'pk'),
('av', 1234567890, '@.com', 'jskdj'),
('raj23', 1234667890, '@..com', 'ksdjfkds'),
('jfsdfsd', 1234567890, '@.com', ''),
('jfsdfsd', 1234567890, '@.com', ''),
('jfsdfsd', 1234567890, '@.com', ''),
('rakesh', 9431590188, '@gmail.com', ''),
('p', 1234567890, '@.com', '');
